from time import perf_counter
from pathlib import Path
from threading import Lock
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from app.model import load_model, validate_features
from app.logging_config import configure_logging

app = FastAPI(title="Country Health Indicators Prediction API",
              description="Educational prediction API trained on synthetic data.")
logger = configure_logging()
_metrics_lock = Lock()
_metrics = {"requests": 0, "total_latency_seconds": 0.0}

class CountryInput(BaseModel):
    country: str = Field(min_length=1, max_length=80)
    life_expectancy: float = Field(ge=0, le=100)
    immunization_rate: float = Field(ge=0, le=100)
    health_spending_pct: float = Field(ge=0, le=100)
    infant_mortality: float = Field(ge=0, le=200)

def predict_one(item: CountryInput):
    started = perf_counter()
    try:
        model = load_model()
        features = validate_features([
            item.life_expectancy, item.immunization_rate,
            item.health_spending_pct, item.infant_mortality
        ])
        prediction = str(model.predict(features)[0])
        logger.info("Prediction completed for country=%s", item.country)
        return {"country": item.country, "predicted_risk": prediction}
    except FileNotFoundError as exc:
        logger.exception("Model artifact missing")
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    finally:
        elapsed = perf_counter() - started
        with _metrics_lock:
            _metrics["requests"] += 1
            _metrics["total_latency_seconds"] += elapsed

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/metrics")
def metrics():
    with _metrics_lock:
        count = _metrics["requests"]
        total = _metrics["total_latency_seconds"]
    return {"prediction_requests": count,
            "average_latency_seconds": total / count if count else 0.0}

@app.post("/predict")
def predict(item: CountryInput):
    return predict_one(item)

@app.post("/predict/batch")
def predict_batch(items: list[CountryInput]):
    if not items:
        raise HTTPException(status_code=422, detail="Provide at least one country.")
    return {"predictions": [predict_one(item) for item in items]}
