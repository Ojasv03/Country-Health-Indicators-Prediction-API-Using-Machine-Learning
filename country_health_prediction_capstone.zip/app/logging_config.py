import logging
from pathlib import Path

def configure_logging(log_file: str = "app.log") -> logging.Logger:
    logger = logging.getLogger("country_health_api")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    target = str(Path(log_file))
    if not any(getattr(handler, "baseFilename", None) == str(Path(target).resolve())
               for handler in logger.handlers if hasattr(handler, "baseFilename")):
        handler = logging.FileHandler(target)
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
    return logger
