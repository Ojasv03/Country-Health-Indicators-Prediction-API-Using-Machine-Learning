from pathlib import Path
import joblib
import numpy as np

MODEL_PATH = Path("models/health_risk_model.joblib")
FEATURES = ["life_expectancy", "immunization_rate", "health_spending_pct", "infant_mortality"]

def load_model(path=MODEL_PATH):
    if not Path(path).exists():
        raise FileNotFoundError(f"Model artifact not found at {path}. Run scripts/train_model.py first.")
    return joblib.load(path)

def validate_features(values):
    array = np.asarray(values, dtype=float)
    if array.shape != (4,) or not np.isfinite(array).all():
        raise ValueError("Exactly four finite numeric features are required.")
    if not 0 <= array[1] <= 100:
        raise ValueError("immunization_rate must be between 0 and 100.")
    if array[2] < 0 or array[3] < 0:
        raise ValueError("health_spending_pct and infant_mortality must be non-negative.")
    if not 0 <= array[0] <= 100:
        raise ValueError("life_expectancy must be between 0 and 100.")
    return array.reshape(1, -1)
