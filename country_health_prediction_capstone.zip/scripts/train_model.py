from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import joblib
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

DATA = Path("data/country_health.csv")
MODEL_OUT = Path("models/health_risk_model.joblib")
REPORTS = Path("reports")
FEATURES = ["life_expectancy", "immunization_rate", "health_spending_pct", "infant_mortality"]
TARGET = "risk_category"

def train():
    if not DATA.exists():
        from scripts.ingest_data import generate_data
        DATA.parent.mkdir(parents=True, exist_ok=True)
        generate_data().to_csv(DATA, index=False)
    df = pd.read_csv(DATA)
    X_train, X_test, y_train, y_test = train_test_split(
        df[FEATURES], df[TARGET], test_size=0.25, random_state=42, stratify=df[TARGET]
    )
    models = {
        "Baseline (most frequent)": DummyClassifier(strategy="most_frequent"),
        "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
    }
    rows = []
    trained = None
    for name, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        rows.append({"model": name, "accuracy": accuracy_score(y_test, pred),
                     "macro_f1": f1_score(y_test, pred, average="macro", zero_division=0)})
        if name == "Logistic Regression":
            trained = model
    MODEL_OUT.parent.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    joblib.dump(trained, MODEL_OUT)
    results = pd.DataFrame(rows)
    results.to_csv(REPORTS / "model_comparison.csv", index=False)
    ax = results.set_index("model")[["accuracy", "macro_f1"]].plot(kind="bar", ylim=(0, 1), rot=10)
    ax.set_title("Model comparison on synthetic test data")
    ax.set_ylabel("Score")
    plt.tight_layout()
    plt.savefig(REPORTS / "model_comparison.png", dpi=150)
    plt.close()
    print(results.to_string(index=False))
    return results

if __name__ == "__main__":
    train()
