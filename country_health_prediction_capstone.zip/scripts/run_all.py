import subprocess
import sys

commands = [
    [sys.executable, "scripts/ingest_data.py"],
    [sys.executable, "scripts/eda.py"],
    [sys.executable, "scripts/train_model.py"],
    [sys.executable, "-m", "pytest", "-q"],
]
for command in commands:
    print("\n>", " ".join(command), flush=True)
    subprocess.run(command, check=True)
print("\nAll pipeline steps and tests passed.")
