from pathlib import Path
import numpy as np
import pandas as pd

OUT = Path("data/country_health.csv")

def generate_data(n=600, seed=42):
    rng = np.random.default_rng(seed)
    life = rng.uniform(48, 84, n)
    immunization = np.clip(rng.normal(78, 13, n), 35, 100)
    spending = np.clip(rng.normal(6.2, 2.1, n), 1.0, 15.0)
    infant = np.clip(105 - life * 1.05 - immunization * 0.35 + rng.normal(0, 8, n), 2, 100)
    score = (life < 63).astype(int) + (immunization < 70).astype(int) + (spending < 4.5).astype(int) + (infant > 35).astype(int)
    risk = np.where(score >= 3, "high", np.where(score >= 1, "medium", "low"))
    return pd.DataFrame({
        "country": [f"SyntheticCountry{i+1:03d}" for i in range(n)],
        "life_expectancy": life.round(1),
        "immunization_rate": immunization.round(1),
        "health_spending_pct": spending.round(2),
        "infant_mortality": infant.round(1),
        "risk_category": risk
    })

if __name__ == "__main__":
    OUT.parent.mkdir(parents=True, exist_ok=True)
    generate_data().to_csv(OUT, index=False)
    print(f"Wrote {OUT} (synthetic demonstration data)")
