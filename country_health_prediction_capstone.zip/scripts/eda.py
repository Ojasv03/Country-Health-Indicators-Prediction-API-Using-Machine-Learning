from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def run_eda():
    data = Path("data/country_health.csv")
    if not data.exists():
        from scripts.ingest_data import generate_data
        data.parent.mkdir(parents=True, exist_ok=True)
        generate_data().to_csv(data, index=False)
    df = pd.read_csv(data)
    Path("reports").mkdir(exist_ok=True)
    df[["life_expectancy", "immunization_rate", "health_spending_pct", "infant_mortality"]].hist(figsize=(9, 6))
    plt.suptitle("Synthetic country health indicators")
    plt.tight_layout()
    plt.savefig("reports/eda_distributions.png", dpi=150)
    plt.close()
    df["risk_category"].value_counts().plot(kind="bar", title="Synthetic risk-category counts")
    plt.tight_layout()
    plt.savefig("reports/eda_risk_categories.png", dpi=150)
    plt.close()
    print("EDA plots saved in reports/")
if __name__ == "__main__":
    run_eda()
