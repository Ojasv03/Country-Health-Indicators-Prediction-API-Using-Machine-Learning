# Country Health Indicators Prediction API

A small, reproducible machine-learning capstone demonstrating data ingestion, exploratory data analysis (EDA), baseline/model comparison, a prediction API, unit tests, logging, performance monitoring, and Docker.

## Project overview
The API predicts a country's illustrative health-risk category from numeric indicators. The included dataset is synthetic and is intended for demonstrating a workflow only; it is not real country statistics and must not be used for policy or medical decisions.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/ingest_data.py
python scripts/train_model.py
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Open `http://127.0.0.1:8000/docs` for interactive API documentation.

## Run tests
```bash
pytest -q
```

## Rebuild all artifacts
```bash
python scripts/run_all.py
```
This creates the synthetic dataset, EDA plots, trained models, comparison chart, and test results.

## Example request
```bash
curl -X POST http://127.0.0.1:8000/predict \
  -H 'Content-Type: application/json' \
  -d '{"country":"Exampleland","life_expectancy":72,"immunization_rate":85,"health_spending_pct":6.5,"infant_mortality":18}'
```

## Endpoints
- `GET /health` — health check
- `GET /metrics` — simple request count and average latency
- `POST /predict` — prediction for one country
- `POST /predict/batch` — predictions for multiple countries

## Tests and isolation
Tests use temporary directories and an in-memory test client. They do not overwrite production model files or production logs. The model is loaded from `models/health_risk_model.joblib` when available; the API has a clear error if artifacts have not been generated.

## Models
The training script compares:
- DummyClassifier baseline
- LogisticRegression model

Metrics are saved to `reports/model_comparison.csv` and a chart is saved to `reports/model_comparison.png`.

## Repository structure
```text
app/                 FastAPI application and logging
data/                generated synthetic CSV dataset
models/              trained model artifacts
notebooks/            EDA notebook placeholder / analysis notes
reports/              generated plots and model metrics
scripts/              data ingestion, training, and run-all workflow
tests/                API, model, and logging tests
Dockerfile
docker-compose.yml
requirements.txt
```

## Limitations
This is an educational demonstration using synthetic data. Model scores only measure performance on that generated dataset; they do not establish real-world predictive value.
