import logging
from app.logging_config import configure_logging

def test_logging_writes_to_separate_temp_file(tmp_path):
    path = tmp_path / "test_app.log"
    logger = configure_logging(str(path))
    logger.info("unit-test-log-message")
    for handler in logger.handlers:
        handler.flush()
    assert path.exists()
    assert "unit-test-log-message" in path.read_text()
