import numpy as np
import pytest
from app.model import validate_features

def test_valid_features_shape():
    result = validate_features([72, 85, 6.5, 18])
    assert result.shape == (1, 4)

def test_immunization_range_rejected():
    with pytest.raises(ValueError):
        validate_features([72, 120, 6.5, 18])

def test_non_finite_rejected():
    with pytest.raises(ValueError):
        validate_features([72, np.nan, 6.5, 18])
