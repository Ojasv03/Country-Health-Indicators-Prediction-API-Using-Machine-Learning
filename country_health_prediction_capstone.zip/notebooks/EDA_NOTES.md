# EDA notes

The `scripts/eda.py` script creates:
- `reports/eda_distributions.png`: distributions of the four numeric indicators.
- `reports/eda_risk_categories.png`: counts for the synthetic target classes.

All data are generated deterministically for educational workflow demonstration and do not represent real countries.
